﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using T1.BL;

namespace T1.BL
{
    public class DegreeProgramBL
    {
        public string title;
        public string duration;
        public int seats;
        public List<SubjectBL> s;
        

        public DegreeProgramBL(string title)
        {
            this.title = title;
        }

        public DegreeProgramBL(string title, string duration, int seats)
        {
            this.title = title;
            this.duration = duration;
            this.seats = seats;
            s = new List<SubjectBL>();
        }
        
        public bool isSujectExists( SubjectBL sub )
        {
            return true;
        }
        
        public void AddSubject ( SubjectBL sub)
        {
            if (calculateCreditHours( sub) + sub.creditHours <= 20)
            {
                s.Add(sub);
            }
            else
            {
                Console.WriteLine("Cannot exceed 20 credit hours.");
            }
        }
        
        public static int calculateCreditHours(SubjectBL s)
        {
            int hours = 0;
            foreach (var subjectType in s)
            {
                hours = hours + s.creditHours;
            }
            return hours;
        }
        
        public void DegreeIsPresent()
        {

        }
    }
}
