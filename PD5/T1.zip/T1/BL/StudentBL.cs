﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using T1.BL;

namespace T1.BL
{
    public class StudentBL
    {
        public string name;
        public int age;
        public float FSCMarks;
        public float EcatMarks;
        public float merit;
        public static List<DegreeProgramBL> prefrences;
        public static List<SubjectBL> regSubjects;

        public StudentBL()
        {

        }
        public StudentBL(string name, int age, float fSCMarks, float ecatMarks)

        {
            this.name = name;
            this.age = age;
            this.FSCMarks = fSCMarks;
            this.EcatMarks = ecatMarks;
            prefrences = new List<DegreeProgramBL>();
            regSubjects = new List<SubjectBL>();
        }

        public static void regStudentSubject(SubjectBL s)
        {
            int totalhours = DegreeProgramBL.calculateCreditHours(s) + s.creditHours;
            if (totalhours <= 9)
            {
                List<SubjectBL> regSubjects1 = new List<SubjectBL>();
                regSubjects.Add(s);
            }
            else
            {
                Console.WriteLine("Number of hours cannot exceed than 9.");
            }
        }

        public static float calculateMerit()
        {
            float fees = 00F;
            foreach (var subject in regSubjects)
            {
                fees = fees + subject.subjectFee;
            }
            return fees;
        }

        public int getCreditHours()
        {
            int hours = 0;

            foreach (var s in regSubjects)
            {
                hours += s.creditHours;
            }
            return hours;
        }

        public static float calculateFee()
        {
            float fees = 00F;

            List<SubjectBL> regSubjects1 = new List<SubjectBL>();
            foreach (var s in regSubjects1)
            {
                fees += s.subjectFee;
            }
            return fees;

        }
    }
}

