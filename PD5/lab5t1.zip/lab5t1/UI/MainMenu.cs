﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lab5t1.UI;

namespace lab5t1.UI
{
    public class MainMenu
    {
        public static int Identity()// confirm identity
        {
            Console.Clear();
            int login;
            Console.WriteLine("                                                                    ");
            Console.WriteLine("                       ---------------------------------------------");
            Console.WriteLine("                       |   SELECT ONE OF THE FOLLOWING OPTIONS:    |");
            Console.WriteLine("                       |    1-Admin                                |");
            Console.WriteLine("                       |    2-User                                 |");
            Console.WriteLine("                       |    3-Exit                                 |");
            Console.WriteLine("                       ---------------------------------------------");
            Console.WriteLine("                                                                    ");
            Console.Write("                       Entered option:");
            login = int.Parse(Console.ReadLine());
            if (login == 1)
            {
                UI.AdminUI.AdminMenu();
            }
            if (login == 2)
            {
                UI.CustomerUI.CustomMenu();
            }
            if (login == 3)
            {
                return 0;
            }
            return login;
        }
        public static int Loginscr()//login function
        {
            int login;
            Console.WriteLine("                                                                   ");
            Console.WriteLine("                      ---------------------------------------------");
            Console.WriteLine("                      |   SELECT ONE OF THE FOLLOWING OPTIONS:    |");
            Console.WriteLine("                      |    1-SignIn                               |");
            Console.WriteLine("                      |    2-SignUp                               |");
            Console.WriteLine("                      |    3-Exit                                 |");
            Console.WriteLine("                      ---------------------------------------------");
            Console.WriteLine("                                                                   ");
            Console.Write("                     Entered option:");
            login = int.Parse(Console.ReadLine());
            if (login == 3)
            {
                return 0;
            }
            return login;
        }
    }
}
