﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using lab5t1;
using lab5t1.UI;


namespace assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "..//..//credential.txt";
            int login =  MainMenu.Loginscr();
            if (login == 1 )
            {
                
            }
            if (login == 2)
            {
                Console.Clear();
                Console.Write("Enter New Name (Only alphabets and should not contain space): ");
                string newuser = Console.ReadLine();
                Console.Write("Enter New Password (Enter a numeric Password only, 5 digits): ");
                int newpass = int.Parse(Console.ReadLine());
                Utility.SignUp(path, newuser, newpass);
            }
        }
    }
}
