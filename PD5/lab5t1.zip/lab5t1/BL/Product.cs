﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5t1.BL
{
    class Product
    {
        public string Productname;
        public string ProductCategory;
        public int Prics;
        public int threshold;

        public Product(string productname, string productCategory, int prics, int threshold)
        {
            this.Productname = productname;
            this.ProductCategory = productCategory;
            this.Prics = prics;
            this.threshold = threshold;
        }
    }
}
